const products = [
    {
        id: "1",
        name: "Wireless Headphones",
        description: "High-quality wireless headphones.",
        quantity: 50,
        category: "ELECTRONICS"
    },
    {
        id: "2",
        name: "Wooden Chair",
        description: "A comfortable wooden chair.",
        quantity: 20,
        category: "FURNITURE"
    },
    {
        id: "3",
        name: "T-Shirt",
        description: "Cotton t-shirt available in various colors.",
        quantity: 100,
        category: "CLOTHING"
    },
    {
        id: "4",
        name: "Lego Building Set",
        description: "Fun building set for kids aged 5 and up.",
        quantity: 30,
        category: "TOYS"
    },
    {
        id: "5",
        name: "Programming Book",
        description: "A comprehensive guide to modern web development.",
        quantity: 10,
        category: "BOOKS"
    },
    {
        id: "6",
        name: "Organic Apples",
        description: "Fresh organic apples from local farms.",
        quantity: 200,
        category: "GROCERIES"
    },
    {
        id: "7",
        name: "Smartphone",
        description: "Latest model smartphone with advanced features.",
        quantity: 25,
        category: "ELECTRONICS"
    },
    {
        id: "8",
        name: "Dining Table",
        description: "Elegant wooden dining table that seats six.",
        quantity: 15,
        category: "FURNITURE"
    },
    {
        id: "9",
        name: "Jeans",
        description: "Stylish denim jeans for casual wear.",
        quantity: 50,
        category: "CLOTHING"
    },
    {
        id: "10",
        name: "Puzzle Game",
        description: "Challenging puzzle game for the whole family.",
        quantity: 40,
        category: "TOYS"
    },
    {
        id: "11",
        name: "Fantasy Novel",
        description: "An epic tale of adventure and magic.",
        quantity: 5,
        category: "BOOKS"
    },
    {
        id: "12",
        name: "Milk",
        description: "Fresh milk from local dairies.",
        quantity: 150,
        category: "GROCERIES"
    }
];

const orders = [
    { id: '1001', orderAmount: '150.00', notes: { id: 'A123', name: 'John Doe' }, orderDate: '2024-10-16T12:30:00Z', product: { id: '1', name: 'Wireless Headphones', quantity: 2 } },
    { id: '1002', orderAmount: '799.99', notes: { id: 'A124', name: 'Jane Smith' }, orderDate: '2024-10-15T10:00:00Z', product: { id: '2', name: 'Smartphone', quantity: 1 } }
];


const resolver = {
    Query: {
        getAllOrders: () => orders,
        getAllProducts: () => products,
        getProductById: (_: any, { id }: {id: string}) => {
            return products.find(product => product.id === id)

        }
    },
    Product: {
        orders: (product: any) => {
            return orders.filter(order => order.product.id === product.id);
        }
    }
};

export default resolver;
