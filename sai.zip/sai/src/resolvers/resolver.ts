const resolver = {
    Query: {
        books: () => []
    },
};

export default resolver;
