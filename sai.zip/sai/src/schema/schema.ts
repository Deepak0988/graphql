import {buildSchema} from "graphql/utilities";

export const schema = buildSchema(`

scalar DateTime

enum Category {
    ELECTRONICS
    FURNITURE
    CLOTHING
    TOYS
    BOOKS
    GROCERIES
}

type Order {
    id: ID!
    orderAmount: String!
    notes: String!
    orderDate: DateTime!
    product: Product!
}

type Product {
    id: ID!
    name: String!
    description: String
    quantity: Int!
    orders: [Order!]!
    category: Category!
}

type Query {
    getAllOrders: [Order!]!
    getAllProducts: [Product!]!
    getProductById(id: ID!): Product
}


# Define the Mutation type
type Mutation {
  addProduct(name: String!, description: String, quantity: Int!, category: Category!): Product!
  createOrder(orderAmount: String!, notes: String, orderDate: String!, productId: ID!): Order!
}

`)
