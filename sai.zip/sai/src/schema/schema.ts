import {buildSchema} from "graphql/utilities";

export const schema = buildSchema(`
    type Book {
    id: ID!
    title: String!
    author: Author!
    available: Boolean
    quantity: Int!
}

type Author {
    name: String
    books: [Book!]!
}

type Query {
    books: [Book!]!
}

`)
