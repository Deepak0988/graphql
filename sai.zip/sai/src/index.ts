import {ApolloServer} from "@apollo/server";
import {schema} from "./schema/schema";
import resolver from "./resolvers/resolver";
import {startStandaloneServer} from "@apollo/server/standalone";

const server = new ApolloServer({
    typeDefs : schema,
    resolvers : resolver,
    introspection : true
});

const start = async () => {
    try {
        await startStandaloneServer(server, {listen: {port: 4000}});
        console.log(`Server is listening on port ${4000}`)
    } catch (error) {
        console.log(error)
    }
}

start().then()
